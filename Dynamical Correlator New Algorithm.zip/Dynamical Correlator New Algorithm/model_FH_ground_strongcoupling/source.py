import numpy  as np
import scipy
import math
from scipy import linalg
import matplotlib
from matplotlib import pyplot as plt

def plot_spec(M):
    dim = len(M[0])
    X = np.linspace(0,dim-1,dim)
    Y = np.zeros(dim)

    eig,vec = np.linalg.eig(M)
    eig_idx = np.argsort(eig)
    for i in range(dim):
        Y[i] = eig[eig_idx[i]].real

    plt.scatter(X,Y)

def plot_phase(U,dim):
    X = np.zeros(dim)
    Y = np.zeros(dim)

    eig,vec = np.linalg.eig(U)
    for i in range(dim):
        X[i] = eig[i].real 
        Y[i] = eig[i].imag 

    plt.scatter(X,Y,marker = '.')
    # plt.show()

def dec_to_bin(num,size):
    array_temp = np.zeros(size)

    for i in range(size):
        num_temp = num%2
        array_temp[size - 1 -i] = num_temp
        num = int(num/2)

    return array_temp

def real_time_unitary(H,t):

    return scipy.linalg.expm(1j*H*t)

def adiabatic_evolution(dim,H1,H2,dt,Num):
    A = np.identity(dim,dtype = complex)

    for count in range(Num):
        s = count/Num
        H_temp = (1-s)*H1 + s*H2
        U_temp = real_time_unitary(H_temp,dt)
        A = A.dot(U_temp)

    return A

def eigenfunc(s):
    return math.sqrt(2*s*s - 2*s +1)

def projector(vec):

    dim = len(vec)
    P = np.zeros((dim,dim),dtype = complex)
    for i in range(dim):
        for j in range(dim):
            P[i][j] = vec[i]*(np.conj(vec[j]))

    return P

def H_X(site):
    dim = 2**site
    M = np.zeros((dim,dim))

    for i in range(dim):
        bin_i = dec_to_bin(i,site)
        for j in range(site):
            if(bin_i[j] == 0):
                tar = int(i + 2**(site - 1 - j))
                M[i][tar] = 1
                M[tar][i] = 1
                
    return M


def SingleX(j,site):
    dim = 2**site
    M = np.zeros((dim,dim))

    for i in range(dim):
        bin_i = dec_to_bin(i,site)
        if(bin_i[j] == 0):
            tar = int(i + 2**(site - 1 - j))
            M[i][tar] = 1
            M[tar][i] = 1
                
    return M

def SingleZ(j,site):
    dim = 2**site
    v = np.zeros(dim)

    for i in range(dim):
        bin_i = dec_to_bin(i,site)
        v[i] = 1 - 2*bin_i[j]

    return np.diag(v)


def SingleY(j,site):
    
    Z = SingleZ(j,site)
    X = SingleX(j,site)

    return 1j*Z.dot(X)

def H_Z(site):
    dim = 2**site
    M = np.zeros((dim,dim))

    for i in range(dim):
        bin_i = dec_to_bin(i,site)
        sum_of_one = 0
        for j in range(site):
            sum_of_one = sum_of_one + bin_i[j]
        M[i][i] = site - 2*sum_of_one

    return M

def H_ZZ(site):
    dim = 2**site
    M = np.zeros((dim,dim))

    for i in range(dim):
        bin_i = dec_to_bin(i,site)
        sum_of_diff = 0
        sum_of_same = 0
        for j in range(site-1):
            if(bin_i[j] != bin_i[j+1]):
                sum_of_diff = sum_of_diff + 1
            else:
                sum_of_same = sum_of_same + 1
        M[i][i] = sum_of_same - sum_of_diff

    return M

def ZZ_pair(L,site1,site2):
    dim = 2**L 
    diag = np.zeros(dim)

    for i in range(dim):
        bin_i = dec_to_bin(i,L)
        if(bin_i[site1] == bin_i[site2]):
            diag[i] = 1
        else:
            diag[i] = -1

    return np.diag(diag)

def XX_pair(L,site1,site2):
    dim = 2**L 
    M = np.zeros((dim,dim))

    for i in range(dim):
        bin_i = dec_to_bin(i,L)
        idx1 = bin_i[site1]
        idx2 = bin_i[site2]
        add = int(2**(L-1-site1)*(1-2*idx1) + 2**(L-1-site2)*(1-2*idx2))
        tar = i + add 
        M[tar][i] = 1 
        M[i][tar] = 1

    return M

def YY_pair(L,site1,site2):

    XX = XX_pair(L,site1,site2)
    ZZ = ZZ_pair(L,site1,site2)

    return -1*(ZZ.dot(XX))


def matrix_norm(M):

    M2 = (np.conj(M).T).dot(M)
    eig,vec = np.linalg.eig(M2)

    mx = np.argmax(eig)
    return math.sqrt(abs(eig[mx]))

def spectral_degeneracy(U,eps,dim):
    G = np.zeros(dim)
    eig,vec = np.linalg.eig(U)
    for i in range(dim):
        G[i] = abs(eig[i]-1)

    deg = 0
    for i in range(dim):
        if (G[i] < eps):
            deg = deg + 1

    return deg

def rep(H,basis,dim):
    M = np.zeros((dim,dim),dtype = complex)

    for i in range(dim):
        vec_i = basis[i]
        for j in range(dim):
            vec_j = basis[j]
            M[i][j] = np.vdot(vec_i,H.dot(vec_j))
    
    return M

def random_err():
    I = np.array([[1,0],[0,1]])
    R = np.random.normal(0, 1, 3)
    if (R[0] >0):
        O = np.array([[0,1],[1,0]])
    else:
        O = np.array([[1,0],[0,-1]])

    if(R[1] > 0):
        OO = np.kron(I,O)
    else:
        OO = np.kron(O,I)

    II = np.kron(I,I)
    if(R[2] > 0):
        return np.kron(OO,II)
    else:
        return np.kron(II,OO)

def rand_vec(dim):

    vec = np.zeros(dim)
    rand_vec = np.random.normal(0,1,dim)

    norm = math.sqrt(abs(np.vdot(rand_vec,rand_vec)))

    for i in range(dim):
        vec[i] = rand_vec[i]/norm 

    return vec

def U_evl(eig,proj,t,dim):

    U = np.zeros((dim,dim),dtype = complex)

    for i in range(dim):
        theta = eig[i].real*t 
        phase = math.cos(theta) - 1j*math.sin(theta)
        # print(phase)
        U = U + phase * proj[i] 

    return U

def norm_distance(M1,M2,dim):

    return matrix_norm(M1 - M2,dim)

def out_product(v1,v2,dim):

    M = np.zeros((dim,dim),dtype = complex)

    for i in range(dim): 
        vi = v1[i]
        for j in range(dim):
            vj = np.conj(v2[j]) 
            M[i][j] = vi*vj 

    return M


def trace(M):

    dim = len(M[0])

    tr = 0 + 1j*0
    for i in range(dim):
        tr = tr + M[i][i]

    return tr

def hubbard_hopping(i1,i2,spin,N):

    dim = 2**(2*N)
    diff = 2**(2*i2 + spin) - 2**(2*i1 + spin)
    M_temp = np.zeros((dim,dim))

    for i in range(dim - diff):
        j = i + diff 
        bin_i = dec_to_bin(i,2*N)

        if(bin_i[2*N - 1 - 2*i1 -spin] == 1 and bin_i[2*N - 1 -2*i2 - spin] == 0):
            M_temp[i][j] = M_temp[j][i] = 1

    return M_temp 

def hubbard_hopping_boundary(spin,N):

    dim = 2**(2*N)
    diff = 2**(2*N -2 + spin) - 2**(spin)

    M_temp = np.zeros((dim,dim))

    for i in range(dim - diff):
        j = i + diff 
        bin_i = dec_to_bin(i,2*N)

        if(bin_i[1 - spin] == 1 and bin_i[2*N - 1 - spin] == 0):
            M_temp[i][j] = M_temp[j][i] = 1

    return M_temp 

def hubbard_energy(N):

    dim = 2**(2*N)
    Diag = np.zeros((dim,dim))

    for i in range(dim):
        n_up = 0
        n_down = 0
        bin_i = dec_to_bin(i,2*N)

        for n in range(N):
            n_up = n_up + bin_i[2*n]
            n_down = n_down + bin_i[2*n + 1]

        Diag[i][i] = (n_up - 0.5)*(n_down - 0.5)

    return Diag

def hubbard_create(i,spin,N):

    dim = 2**(2*N)
    diff = 2**(2*i + spin)
    M_temp = np.zeros((dim,dim))

    for dig1 in range(dim - diff):
        dig2 = dig1 + diff 
        bin_1 = dec_to_bin(dig1,2*N)

        if(bin_1[2*N - 1 - 2*i -spin] == 0):
            M_temp[dig2][dig1] = 1

    return M_temp 

def hubbard_annihilate(i,spin,N):

    dim = 2**(2*N)
    diff = 2**(2*i + spin)
    M_temp = np.zeros((dim,dim))

    for dig1 in range(diff,dim):
        dig2 = dig1 - diff 
        bin_1 = dec_to_bin(dig1,2*N)

        if(bin_1[2*N - 1 - 2*i -spin] == 1):
            M_temp[dig2][dig1] = 1

    return M_temp